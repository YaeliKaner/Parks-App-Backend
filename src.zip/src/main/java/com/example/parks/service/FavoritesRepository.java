package com.example.parks.service;

import com.example.parks.model.Favorites;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FavoritesRepository extends JpaRepository<Favorites, Long> {
    List<Favorites> findFavoritesByUserId(Long id);
}

