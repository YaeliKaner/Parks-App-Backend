package com.example.parks.service.mappers;

import com.example.parks.dto.ParkDesignDTO;
import com.example.parks.model.Features;
import com.example.parks.model.ParkDesign;
import com.example.parks.model.Parks;
import com.example.parks.model.RatingsBreakdown;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface ParkDesignMapper {

    ParkDesignDTO toDto(ParkDesign e);

     ParkDesign toEntity(ParkDesignDTO d);
}
