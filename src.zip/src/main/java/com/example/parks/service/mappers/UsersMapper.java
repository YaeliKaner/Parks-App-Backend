package com.example.parks.service.mappers;

import com.example.parks.PersonalStatus;
import com.example.parks.dto.UsersDTO;
import com.example.parks.dto.UsersLogInDTO;
import com.example.parks.dto.UsersSignUpDTO;
import com.example.parks.model.Cities;
import com.example.parks.model.Users;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface UsersMapper {

}
