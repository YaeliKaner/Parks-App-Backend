package com.example.parks.service;

import com.example.parks.model.Cities;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.parks.model.Parks;
import org.springframework.data.jpa.repository.JpaRepository;


public interface CitiesRepository extends JpaRepository<Cities, Long> {

}