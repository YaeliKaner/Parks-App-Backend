package com.example.parks.service.mappers;

import com.example.parks.dto.ReportsDTO;
import com.example.parks.model.Parks;
import com.example.parks.model.Reports;
import com.example.parks.model.Users;
import org.mapstruct.Mapper;

import java.nio.file.*; import java.util.Base64;

@Mapper(componentModel = "spring")
public interface ReportsMapper {
}
