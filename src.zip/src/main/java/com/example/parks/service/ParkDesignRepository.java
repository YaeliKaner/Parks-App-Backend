package com.example.parks.service;

import com.example.parks.model.ParkDesign;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ParkDesignRepository extends JpaRepository<ParkDesign, Long> {
}
