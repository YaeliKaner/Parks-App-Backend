package com.example.parks.service;

import com.example.parks.model.RatingsBreakdown;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RatingsBreakdownRepository extends JpaRepository<RatingsBreakdown, Long> {
}
