package com.example.parks.service;

import com.example.parks.model.Parks;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ParksRepository extends JpaRepository<Parks, Long> {

    List<Parks> findParksByCityId(Long id);
    List<Parks> findAllByOrderByUpdateDateDesc();

//    List<Parks> findParksByFeatureId(Long id);
}
