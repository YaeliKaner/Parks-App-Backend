package com.example.parks.Controller;

import com.example.parks.model.RatingsBreakdown;
import com.example.parks.service.RatingsBreakdownRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
    @RequestMapping("/api/RatingsBreakdown")
   // @CrossOrigin
    public class RatingsBreakdownController {

        RatingsBreakdownRepository ratingsBreakdownRepository;

        @Autowired
        public RatingsBreakdownController( RatingsBreakdownRepository ratingsBreakdownRepository) {
            this.ratingsBreakdownRepository = ratingsBreakdownRepository;
        }
    @GetMapping("/getRatingsBreakdown")
    public ResponseEntity<List<RatingsBreakdown>> getRatingsBreakdown() {
        try {
            return new ResponseEntity<>(ratingsBreakdownRepository.findAll(), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    }


