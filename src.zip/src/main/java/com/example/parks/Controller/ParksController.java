package com.example.parks.Controller;


import com.example.parks.dto.ParksDTO;
import com.example.parks.model.*;
//import com.example.parks.service.ImageUtils;
import com.example.parks.service.ImageUtils;
import com.example.parks.service.UsersRepository;
import com.example.parks.service.mappers.ParksMapper;
import com.example.parks.service.ParksRepository;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/parks")
//@CrossOrigin
public class ParksController {

    ParksRepository parksRepository;
    ParksMapper parksMapper;
    UsersRepository usersRepository;

    @Autowired
    public ParksController(ParksRepository parksRepository, ParksMapper parksMapper, UsersRepository usersRepository) {
        this.parksRepository = parksRepository;
        this.parksMapper = parksMapper;
        this.usersRepository = usersRepository;
    }


//    public ParksController(ParksRepository parksRepository, ParksMapper parksMapper) {
//        this.parksRepository=parksRepository;
//        this.parksMapper=parksMapper;
//
//    }



    @GetMapping("/test")
    public ResponseEntity<String> test() {
        return new ResponseEntity<>("Controller is working!", HttpStatus.OK);
    }

//    @GetMapping("/getParkById/{id}")
//    public ResponseEntity<ParksDTO> get(@PathVariable long id) throws IOException {
//        Parks parks = parksRepository.findById(id).get();
//        if(p!=null)
//            return new ResponseEntity<>(parkToDto(),HttpStatus.OK);
//        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
//    }

    @GetMapping("/getParks")
    public ResponseEntity<List<ParksDTO>> getParks() {
        try {
            List<Parks> parks = parksRepository.findAllByOrderByUpdateDateDesc();
            return new ResponseEntity<>(parksMapper.parksToDto(parks), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/getParksByCityId/{id}")
    public ResponseEntity<List<Parks>> getParksByCityId(@PathVariable Long id) {
        try {
            return new ResponseEntity<>(parksRepository.findParksByCityId(id), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
//    @GetMapping("/getParksByFeatureId/{id}")
//    public ResponseEntity<List<Parks>> getParksByFeatureId(@PathVariable Long id) {
//        try {
//            return new ResponseEntity<>(parksRepository.findParksByFeatureId(id), HttpStatus.OK);
//        } catch (Exception e) {
//            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
//        }
//    }
    @PostMapping("/uploadPark")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<Parks> uploadParkWithImage(@RequestPart("image") MultipartFile file
            ,@RequestPart("Park") Parks p) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            String userEmail = authentication.getName();
            Users authenticatedUser = usersRepository.findByEmail(userEmail);
            if(authenticatedUser == null){
                return new ResponseEntity<>(null, HttpStatus.FORBIDDEN);
            }

            ImageUtils.uploadImage(file);
            p.setPicturePath(file.getOriginalFilename());
            p.setUploadDate(LocalDate.now());
            p.setUpdateDate(LocalDate.now());
            p.setUser(authenticatedUser);
            Parks park= parksRepository.save(p);
            return new ResponseEntity<>(park,HttpStatus.CREATED);
        }
        catch (IOException e) {
            System.out.println(e);
            return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/updatePark")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<Parks> updatePark(@RequestPart("image") MultipartFile file,
                                            @RequestPart("Park") Parks p){
        Parks park = parksRepository.findById(p.getId()).get();
        if(park == null){
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentUserEmail = authentication.getName();
        if(!((park.getUser().getEmail()).equals(currentUserEmail))){
            return new ResponseEntity<>(null, HttpStatus.FORBIDDEN);
        }
        try{
            ImageUtils.uploadImage(file);
            park.setPicturePath(file.getOriginalFilename());
            park.setUpdateDate(LocalDate.now());
            park.setName(p.getName());
            park.setDesc(p.getDesc());
            park.setAddress(p.getAddress());
            park.setCity(p.getCity());
            parksRepository.save(park);
            return new ResponseEntity<>(park, HttpStatus.OK);
        }
     catch (Exception e) {
        return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
    }
    }

}
