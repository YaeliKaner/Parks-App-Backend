package com.example.parks.Controller;

import com.example.parks.dto.ParksDTO;
import com.example.parks.model.Cities;
import com.example.parks.model.Parks;
import com.example.parks.service.CitiesRepository;
import com.example.parks.service.ParksRepository;
import com.example.parks.service.mappers.ParksMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api/cities")
//@CrossOrigin
public class CitiesController {

    CitiesRepository citiesRepository;

    @Autowired
    public CitiesController(CitiesRepository citiesRepository) {
        this.citiesRepository = citiesRepository;
    }

    @GetMapping("/getCityById/{id}")
    public ResponseEntity<Cities> get(@PathVariable long id) throws IOException {
        Cities c = citiesRepository.findById(id).get();
        if (c != null)
            return new ResponseEntity<>(c, HttpStatus.OK);
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}


//
//    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
//    public ResponseEntity<Cities> create(
//            @RequestPart("data") Cities dto,
//            @RequestPart(value = "image", required = false) MultipartFile image) {
//        try {
//            return new ResponseEntity<>(p.create(dto, image), HttpStatus.CREATED);
//        } catch (Exception ex) {
//            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
//        }
//    }
//
//    @PutMapping("/{id}")
//    public ResponseEntity<CitiesDTO> update(@PathVariable Long id, @RequestBody CitiesDTO dto) {
//        try {
//            return ResponseEntity.ok(service.update(id, dto));
//        } catch (RuntimeException ex) {
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
//        }
//    }
//
//    @DeleteMapping("/{id}")
//    public ResponseEntity<Void> delete(@PathVariable Long id) {
//       r.delete(id);
//        return ResponseEntity.noContent().build();
//    }
//}
