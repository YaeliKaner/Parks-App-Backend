package com.example.parks.Controller;

import com.example.parks.model.Features;
import com.example.parks.service.FeaturesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/features")
//@CrossOrigin
public class FeaturesController {

    FeaturesRepository featuresRepository;


    @Autowired
    public FeaturesController(FeaturesRepository featuresRepository) {
        this.featuresRepository = featuresRepository;

    }


}