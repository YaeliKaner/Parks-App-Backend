package com.example.parks.Controller;


import com.example.parks.dto.ParksDTO;
import com.example.parks.model.Parks;
//import com.example.parks.service.ImageUtils;
import com.example.parks.model.Reports;
import com.example.parks.service.ImageUtils;
import com.example.parks.service.ReportsRepository;
import com.example.parks.service.mappers.ParksMapper;
import com.example.parks.service.ParksRepository;
import com.example.parks.service.mappers.ReportsMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api/Reports")
//@CrossOrigin
public class ReportsController {

    ReportsRepository reportsRepository;
    ReportsMapper reportsMapper;

    @Autowired
    public ReportsController(ReportsRepository reportsRepository, ReportsMapper reportsMapper) {
        this.reportsRepository=reportsRepository;
        this.reportsMapper= reportsMapper;
    }


    @GetMapping("/getReportsByParkId/{id}")
    public ResponseEntity<List<Reports>> getReportsByParkId(@PathVariable Long id) {
        try {
            return new ResponseEntity<>( reportsRepository.findReportsByParkId(id), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @PostMapping("/uploadReport")
    public ResponseEntity<Reports> uploadReportWithImage(@RequestPart("image") MultipartFile file
            ,@RequestPart("") Reports r) {
        try {
            ImageUtils.uploadImage(file);
            r.setPicturePath(file.getOriginalFilename());
            Reports report= reportsRepository.save(r);
            return new ResponseEntity<>(report,HttpStatus.CREATED);

        } catch (IOException e) {
            System.out.println(e);
            return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
        }


    }
}
