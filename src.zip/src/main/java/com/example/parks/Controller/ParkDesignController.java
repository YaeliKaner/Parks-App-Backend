package com.example.parks.Controller;


import com.example.parks.model.ParkDesign;
import com.example.parks.service.ParkDesignRepository;
import com.example.parks.service.mappers.ParkDesignMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/parkDesign")
//@CrossOrigin
public class ParkDesignController {

    ParkDesignRepository parkDesignRepository;
    ParkDesignMapper parkDesignMapper;

    @Autowired
    public ParkDesignController(ParkDesignRepository parkDesignRepository, ParkDesignMapper parkDesignMapper) {
        this.parkDesignRepository=parkDesignRepository;
        this.parkDesignMapper=parkDesignMapper;

    }

}