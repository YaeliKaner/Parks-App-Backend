package com.example.parks.Controller;

import com.example.parks.dto.ParksDTO;
import com.example.parks.model.Favorites;
import com.example.parks.model.Parks;
import com.example.parks.service.FavoritesRepository;
import com.example.parks.service.ParkDesignRepository;
import com.example.parks.service.ParksRepository;
import com.example.parks.service.mappers.ParksMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api/favorites")
//@CrossOrigin
public class FavoritesController {

    FavoritesRepository favoritesRepository;

    @Autowired
    public FavoritesController(FavoritesRepository favoritesRepository) {
        this.favoritesRepository = favoritesRepository;
    }


    @GetMapping("/getFavoritesByUserId/{id}")
    public ResponseEntity<List<Favorites>> getFavoritesByUserId(@PathVariable Long id){
        try{
            return new ResponseEntity<> (favoritesRepository.findFavoritesByUserId(id), HttpStatus.OK);
        }
        catch(Exception e){
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}


