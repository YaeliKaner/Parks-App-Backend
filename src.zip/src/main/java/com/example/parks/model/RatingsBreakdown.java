package com.example.parks.model;


import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

import java.util.List;

@Entity
public class RatingsBreakdown {
    @Id
    @GeneratedValue
    private Long id;
    private String desc;

    @OneToMany(mappedBy = "ratingDetails")
    @JsonIgnore
    private List<ParkDesign> parkDesigns;

    public RatingsBreakdown() {}

    public RatingsBreakdown(Long id, String desc, List<ParkDesign> parkDesigns) {
        this.id = id;
        this.desc = desc;
        this.parkDesigns = parkDesigns;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public List<ParkDesign> getParkDesigns() {
        return parkDesigns;
    }

    public void setParkDesigns(List<ParkDesign> parkDesigns) {
        this.parkDesigns = parkDesigns;
    }
}
