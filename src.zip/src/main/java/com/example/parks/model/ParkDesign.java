package com.example.parks.model;

import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
public class ParkDesign {
    @Id
    @GeneratedValue
    private Long id;
    private LocalDate updateDate;
    private String remark;

    @ManyToOne
    private Parks park;

    @ManyToOne
    private Features feature;

    @ManyToOne
    private RatingsBreakdown ratingDetails;

    public ParkDesign() {}

    public ParkDesign(Long id, LocalDate updateDate, String remark, Parks park, Features feature, RatingsBreakdown ratingDetails) {
        this.id = id;
        this.updateDate = updateDate;
        this.remark = remark;
        this.park = park;
        this.feature = feature;
        this.ratingDetails = ratingDetails;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDate getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(LocalDate updateDate) {
        this.updateDate = updateDate;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Parks getPark() {
        return park;
    }

    public void setPark(Parks park) {
        this.park = park;
    }

    public Features getFeature() {
        return feature;
    }

    public void setFeature(Features feature) {
        this.feature = feature;
    }

    public RatingsBreakdown getRatingDetails() {
        return ratingDetails;
    }

    public void setRatingDetails(RatingsBreakdown ratingDetails) {
        this.ratingDetails = ratingDetails;
    }
}
