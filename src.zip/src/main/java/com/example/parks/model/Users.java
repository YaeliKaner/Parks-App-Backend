package com.example.parks.model;



import com.example.parks.PersonalStatus;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
public class Users {

    @Id
    @GeneratedValue
    private Long id;
    private String name;
    private String password;
    private LocalDate birthDate;
    @ManyToOne
    private Cities city;
    private String phone;
    private String email;
    @Enumerated(EnumType.STRING)
    private PersonalStatus personalStatus;

    @OneToMany(mappedBy = "user")
    @JsonIgnore
    private List<Parks> parks;

    @OneToMany(mappedBy = "user")
    @JsonIgnore
    private List<Reports> reports;

    @OneToMany(mappedBy = "user")
    @JsonIgnore
    private List<Favorites> favorites;

    @ManyToMany
    private Set<Role> roles = new HashSet<>();


    public Users() {}


    public Users(Long id, String name, String password, LocalDate birthDate, Cities city, String phone, String email, PersonalStatus personalStatus, List<Parks> parks, List<Reports> reports, List<Favorites> favorites, Set<Role> roles) {
        this.id = id;
        this.name = name;
        this.password = password;
        this.birthDate = birthDate;
        this.city = city;
        this.phone = phone;
        this.email = email;
        this.personalStatus = personalStatus;
        this.parks = parks;
        this.reports = reports;
        this.favorites = favorites;
        this.roles = roles;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public LocalDate getBirthSDate() {
        return birthDate;
    }

    public void setBirthSDate(LocalDate birthSDate) {
        this.birthDate = birthSDate;
    }

    public Cities getCity() {
        return city;
    }

    public void setCity(Cities city) {
        this.city = city;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public PersonalStatus getPersonalStatus() {
        return personalStatus;
    }

    public void setPersonalStatus(PersonalStatus personalStatus) {
        this.personalStatus = personalStatus;
    }

    public List<Parks> getParks() {
        return parks;
    }

    public void setParks(List<Parks> parks) {
        this.parks = parks;
    }

    public List<Reports> getReports() {
        return reports;
    }

    public void setReports(List<Reports> reports) {
        this.reports = reports;
    }

    public List<Favorites> getFavorites() {
        return favorites;
    }

    public void setFavorites(List<Favorites> favorites) {
        this.favorites = favorites;
    }

    public LocalDate getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(LocalDate birthDate) {
        this.birthDate = birthDate;
    }

    public Set<Role> getRoles() {
        return roles;
    }

    public void setRoles(Set<Role> roles) {
        this.roles = roles;
    }
}
