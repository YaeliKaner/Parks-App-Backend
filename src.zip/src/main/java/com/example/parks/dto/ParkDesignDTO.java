package com.example.parks.dto;

import com.example.parks.model.Features;
import com.example.parks.model.Parks;
import com.example.parks.model.RatingsBreakdown;

import java.time.LocalDate;

public class ParkDesignDTO {

    private LocalDate updateDate;
    private String remark;

    private Parks park;

    private Features feature;

    private RatingsBreakdown ratingDetails;

    public LocalDate getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(LocalDate updateDate) {
        this.updateDate = updateDate;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Parks getPark() {
        return park;
    }

    public void setPark(Parks park) {
        this.park = park;
    }

    public Features getFeature() {
        return feature;
    }

    public void setFeature(Features feature) {
        this.feature = feature;
    }

    public RatingsBreakdown getRatingDetails() {
        return ratingDetails;
    }

    public void setRatingDetails(RatingsBreakdown ratingDetails) {
        this.ratingDetails = ratingDetails;
    }
}
